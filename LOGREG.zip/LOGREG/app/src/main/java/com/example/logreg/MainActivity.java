package com.example.logreg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText input_email, input_pass;
    Button button_login, button_register;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBHelper(this);

        input_email = findViewById(R.id.input_email);
        input_pass = findViewById(R.id.input_pass);
        button_login = findViewById(R.id.button_login);
        button_register = findViewById(R.id.button_register);

        button_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(registerIntent);
            }
        });

        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = input_email.getText().toString().trim();
                String pass = input_pass.getText().toString().trim();
                boolean res = db.checkUser(email, pass);
                if(res)
                {
                    Intent HomePage = new Intent(MainActivity.this,HomeActivity.class);
                    getIntent().putExtra("email", email);
                    startActivity(HomePage);
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Hibás adatok!",Toast.LENGTH_SHORT).show();
                }
            }
        });
        init();
    }

    private void init(){

    }
}