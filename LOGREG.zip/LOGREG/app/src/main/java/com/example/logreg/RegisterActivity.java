package com.example.logreg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText input_email, input_name, input_pass, input_pass2;
    Button button_create, button_back;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DBHelper(this);
        init();
    }

    private  void init(){
        input_email = findViewById(R.id.input_email);
        input_name = findViewById(R.id.input_name);
        input_pass = findViewById(R.id.input_pass);
        input_pass2 = findViewById(R.id.input_pass2);
        button_create = findViewById(R.id.button_create);
        button_back = findViewById(R.id.button_back);

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainIntent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(mainIntent);
            }
        });

        button_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = input_email.getText().toString().trim();
                String name = input_name.getText().toString().trim();
                String pass = input_pass.getText().toString().trim();
                String pass2 = input_pass2.getText().toString().trim();

                if(email.isEmpty() || name.isEmpty() || pass.isEmpty()){
                    Toast.makeText(RegisterActivity.this,"Tölts ki minden mezőt",Toast.LENGTH_SHORT).show();
                } else {
                    if(pass.equals(pass2)){
                        long val = db.addUser(name,email,pass);
                        if(val > 0){
                            Toast.makeText(RegisterActivity.this,"Sikeres regisztráció",Toast.LENGTH_SHORT).show();
                            Intent moveToLogin = new Intent(RegisterActivity.this,MainActivity.class);
                            startActivity(moveToLogin);
                        }
                        else{
                            Toast.makeText(RegisterActivity.this,"Sikertelen regisztráció",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(RegisterActivity.this,"A jelszavak nem egyeznek",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}