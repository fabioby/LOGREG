package com.example.logreg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {
    Button button_logout;
    TextView email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        init();
    }

    private void init(){
        button_logout = findViewById(R.id.button_logout);
        email = findViewById(R.id.text_welcome);
        Bundle HomePage = getIntent().getExtras();

        email.setText(HomePage.getString("email"));

        button_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(HomeActivity.this, MainActivity.class);
                startActivity(registerIntent);
            }
        });
    }
}